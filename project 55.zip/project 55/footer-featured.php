<div id="footer">
<span id="copyright">&copy; <?php echo date("Y");?>, <?php printf(__('Powered by <a href="%s">WordPress</a>. Designed by <a href="%s">Hoo Themes</a>.','singlepage'),esc_url('http://wordpress.org/'),esc_url('http://www.hoothemes.com/'));?></span>
        </div>
       <?php wp_footer();?>
</body>
</html>