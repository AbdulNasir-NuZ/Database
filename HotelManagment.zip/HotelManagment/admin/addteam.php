
<form action="addteamexec.php" method="POST">
Team Name<br>
<input type="text" name="name" /><br>
Team Leader<br>
<input type="text" name="leader" /><br>
<input type="submit" value="Save" />
</form>