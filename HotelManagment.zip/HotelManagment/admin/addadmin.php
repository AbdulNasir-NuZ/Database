<form action="saveadminaccount.php" method="post">
Username<br>
<input type="text" name="username" value="" /><br>
Password<br>
<input type="text" name="password" value="" /><br>
Power<br>
<input type="text" name="power" value="" /><br>
<input type="submit" value="Save">
</form>