<div style="text-align:center; font-weight:bold;">Terms and Condition</div><br />
<p>1. Catering is within the area of NEGROS OCCIDENTAL only.</p>
<p>2. Additional 10% payment on reservation outside Bacolod City.</p>
<p>3. Additional  php3,000 for the reservation on Funtion Hall.</p>
<p>4. MINIMUM Pax For Lunch nd Dinner 50px , Merienda 100px and for the Specialty 30px .</p>
<p>5. Costumer must pay 50% of the actual price as an advance payment 3 days after confirmation, if the costumer failed to pay the said advance payment reservation will be cancelled.</p>
<p>6. The management will call the costumer about the payment details.</p>
<p>7. If the costumer wants to cancel its confirmed reservation due to personal reason, the management will get 20% from the advance payment he/she made as charge for the damages.</p>