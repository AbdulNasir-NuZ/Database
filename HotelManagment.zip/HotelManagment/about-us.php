<html>
<head>
<title>Company Name</title>
<link rel="icon" type="image/png" href="images/favicon.png" />
<link href="css/style.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="row-top">
		<div class="main">
			<div class="wrapper">
				<h1><a href="">Company Name<br><span style="font-family: arial; font-size: 15px;">Restaurant</span></a></h1>
				<nav>
				  <ul class="menu">
					<li><a href="index.php">Home</a></li>
					<li><a href="menu.php">Menu</a></li>
					<li><a href="functionhall.php">Function Hall</a></li>
					<li><a href="reservation.php">Reservation</a></li>
					<li><a class="active" href="about-us.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="loginform.php">login</a></li>
				  </ul>
				</nav>
			</div>
		</div>
	</div>
	<div class="row-bot">
		<div class="row-bot-bg">
			<div class="maincon">
				<div class="slider-wrapper">
					<div class="slider">
						<div id="slidercon">
							<div id="about" style="overflow: scroll; height: 422px; margin-top: 13px; font-size: 15px;">
							<div id="title">
								
							</div>
							<div id="about" style="height: 165px; width: 279px;">
								<!--Edit Here-->
								<img src="images/logo.png" style="float: left; width: 88px; margin-right: 7px;"/>DnG Comedor Restaurant was established by Ms. Gina Cordeta with her business partner on June 25, 2012. Located at the corner of Rosario -Verbena Street occupying two storey building in the area. With its good foods and services this made them competitive in the business.
								
							</div>
							<div id="title">
								Our Mission
							</div>
							<div id="about" style="height:67px; width: 279px;">
								<!--Edit Here-->
								To be the best and most admired family retaurant operator in the Philippines by caring our people, products, services and to our customers.
							</div>
							<div id="title">
								Our Vision
							</div>
							<div id="about" style="height:100px; width: 279px;">
								<!--Edit Here-->
							    We will go out of way to provide our guest with a great memorable dining experience.
							</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="footer">&copy; Copyright Company Name</div>
</body>
</php>